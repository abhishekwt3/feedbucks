export const SHOPIFY_API_KEY = '81efd528527cdd7305a2a730d326e427';
export const SHOPIFY_API_SECRET = '7f057bd74dbc312344e6ef53c92b9fbc';
export const SCOPES = ['read_products', 'write_products', 'read_script_tags', 'write_script_tags'];
export const HOST = process.env.HOST || 'https://your-app-url.com';

